#ifndef WIN_H_
#define WIN_H_

#include <stddef.h>
#include <stdio.h>
#include <windows.h>
#include <stdlib.h>
#include <process.h>
#include <direct.h>

#endif


